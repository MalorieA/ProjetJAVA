package fr.chalodss.spaceinvaders.classes;

public enum EState {
    ALIVE, DEAD
}
