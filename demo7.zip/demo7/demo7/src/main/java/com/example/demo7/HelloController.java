package com.example.demo7;

import javafx.animation.AnimationTimer;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.layout.Pane;




public class HelloController {



    @FXML

    private Pane board;
    @FXML
    private void init() {

    }

    @FXML
    private void start() {

    }
    @FXML
    private void reset() {
    }
}